
Subfolder Wave1_Comprehensive_Codebook contains two large files of the Wave 1 variables.

	Older version of Wave 1 Codebook
	21600-0001-Codebook_Questionnaire.pdf
		In Home Questionnaire Code Book, Public Use Sample
		In School Questionniare Code Book, Public Use Sample
		Parental Questionnaire Code Book, Public Use Sample
		Section A: Setup of CAPI Interview

	New version of Wave 1 Codebook
	21600-0001-Frequencies.pdf
		AID, IMONTH, IDAY, SCH_YR, BIO_SEX, VERSION, SMP01, SMP03
		H1 variables (In Home sample)
		S variables (School sample)
		P variables (Parent sample)
		AH_PVT, AH_RAW (vocabulary test score)

Subfolder Wave1_InHome_Codebooks contains older codebooks organized into separate files 
for each section of the Wave 1 In-Home sample variables.  
	W1NDXPUB.PDF	index of Wave 1 In-Home variable sections